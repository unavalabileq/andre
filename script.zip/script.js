const cardsContainer = document.getElementById("cards");
const cards = Array.from(cardsContainer.children);
const drawnCardContainer = document.getElementById("drawn-card");

function shuffle() {
  cardsContainer.style.display = "flex";
  cards.sort(() => Math.random() - 0.5);
  cards.forEach(card => cardsContainer.appendChild(card));
}

function draw() {
  const drawnCard = cardsContainer.firstElementChild;
  drawnCard.classList.add("drawn");
  drawnCardContainer.innerHTML = drawnCard.innerHTML;
  cardsContainer.removeChild(drawnCard);
  if (cardsContainer.childElementCount === 0) {
    cardsContainer.style.display = "none";
  } else {
    cards.forEach(card => card.classList.add("hidden"));
    cardsContainer.firstElementChild.classList.remove("hidden");
  }
}